/*********************************************************************************
* WEB422 – Assignment 1
*
* I declare that this assignment is my own work in accordance with Seneca's
* Academic Integrity Policy:
*
* https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
*
* Name: Vivek Patel Student ID: 146973235 Date: 2024-10-03
*
********************************************************************************/

import { useEffect, useState } from 'react';
import useSWR from 'swr';
import { useRouter } from 'next/router';
import Pagination from 'react-bootstrap/Pagination';
import Table from 'react-bootstrap/Table';
import PageHeader from '@/components/PageHeader';
import styles from '@/styles/Home.module.css';

const author = 'Terry Pratchett';

export default function Home() {
  const [page, setPage] = useState(1);
  const [pageData, setPageData] = useState(null);
  const router = useRouter();

  const { data, error } = useSWR(
    page
      ? `https://openlibrary.org/search.json?author=${encodeURIComponent(
          author,
        )}&page=${page}&limit=10`
      : null,
  );

  useEffect(() => {
    if (data) {
      setPageData(data);
    }
  }, [data]);

  const previous = () => {
    setPage((current) => (current > 1 ? current - 1 : current));
  };

  const next = () => {
    setPage((current) => current + 1);
  };

  const books = pageData?.docs ?? [];

  return (
    <div>
      <PageHeader text={`Novels by ${author}`} />
      {error && (
        <p className="text-danger">An error occurred while loading the book list.</p>
      )}
      <Table striped hover responsive>
        <thead>
          <tr>
            <th>Title</th>
            <th>First Published</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr
              key={book.key}
              className={styles.tableRow}
              onClick={() => router.push(book.key)}
              role="button"
            >
              <td>{book.title}</td>
              <td>{book.first_publish_year ?? 'N/A'}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      <Pagination className="justify-content-center">
        <Pagination.Prev onClick={previous} disabled={page <= 1} />
        <Pagination.Item active>{page}</Pagination.Item>
        <Pagination.Next onClick={next} />
      </Pagination>
    </div>
  );
}
