import { useRouter } from 'next/router';
import useSWR from 'swr';
import Error from 'next/error';
import BookDetails from '@/components/BookDetails';
import PageHeader from '@/components/PageHeader';

export default function WorkDetails() {
  const router = useRouter();
  const { workId } = router.query;

  const { data, error, isLoading } = useSWR(() =>
    workId ? `https://openlibrary.org/works/${workId}.json` : null,
  );

  if (isLoading || !workId) {
    return null;
  }

  if (error || !data || Object.keys(data).length === 0) {
    return <Error statusCode={404} />;
  }

  return (
    <div>
      <PageHeader text={data.title ?? 'Book Details'} />
      <BookDetails book={data} />
    </div>
  );
}
