import Head from 'next/head';
import Link from 'next/link';
import { Container, Nav, Navbar } from 'react-bootstrap';

function Layout({ children }) {
  return (
    <>
      <Head>
        <title>WEB422 Assignment 1</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <Navbar bg="dark" variant="dark" expand="md" className="mb-4">
        <Container>
          <Navbar.Brand as={Link} href="/">
            WEB422 Assignment 1
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="main-navbar" />
          <Navbar.Collapse id="main-navbar">
            <Nav className="me-auto">
              <Nav.Link as={Link} href="/">
                Home
              </Nav.Link>
              <Nav.Link as={Link} href="/about">
                About
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <main>
        <Container>{children}</Container>
      </main>
      <footer className="py-4 text-center text-muted small">
        <Container>
          &copy; {new Date().getFullYear()} WEB422 Assignment 1
        </Container>
      </footer>
    </>
  );
}

export default Layout;
